package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.example.*")
public class BooksCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksCrudApplication.class, args);
	}

}
