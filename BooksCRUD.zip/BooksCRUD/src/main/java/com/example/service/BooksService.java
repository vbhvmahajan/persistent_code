package com.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.implementation.BookRepository;
import com.example.model.Book;

@Service
public class BooksService {

	@Autowired
	BookRepository repository;
	
	
	public List<Book> getAllBooks()
    {
        List<Book> bookList = repository.findAll();
         
        if(bookList.size() > 0) {
            return bookList;
        } else {
            return new ArrayList<Book>();
        }
    }
	
	
	public Book getBookById(Long id) throws Exception
    {
        Optional<Book> book = repository.findById(id);
         
        if(book.isPresent()) {
            return book.get();
        } else {
            throw new Exception("No book record exist for given id");
        }
    }
	
	
	
	public Book createOrUpdateBook(Book entity) throws Exception
    {
        Optional<Book> book = repository.findById(entity.getId());
         
        if(book.isPresent())
        {
            Book newEntity = book.get();
            newEntity.setName(entity.getName());
            newEntity.setDepartment(entity.getDepartment());
            newEntity.setGenre(entity.getGenre());
 
            newEntity = repository.save(newEntity);
             
            return newEntity;
        } else {
            entity = repository.save(entity);
             
            return entity;
        }
    }
	
	
	public void deleteBookById(Long id) throws Exception 
    {
        Optional<Book> book = repository.findById(id);
         
        if(book.isPresent())
        {
            repository.deleteById(id);
        } else {
            throw new Exception("No book record exist for given id");
        }
    }
}
