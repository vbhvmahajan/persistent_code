
INSERT INTO Books  (name,department,genre) VALUES ('Spring Boot', 'IT' ,'Technology');
INSERT INTO Books (name,department,genre) VALUES ('Spring MVC', 'CSE' ,'Science');