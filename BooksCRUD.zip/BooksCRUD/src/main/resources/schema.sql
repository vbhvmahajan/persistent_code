CREATE TABLE  Books (
 id bigint(20) NOT NULL AUTO_INCREMENT,
 name varchar(200) NOT NULL,
 department varchar(200),
 genre varchar(200),
 PRIMARY KEY (id)
);